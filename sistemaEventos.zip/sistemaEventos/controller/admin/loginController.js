async function abretela(req, res) {
  res.render("admin/login.ejs");
}

async function logar(req, res) {}

module.exports = { abretela, logar };
